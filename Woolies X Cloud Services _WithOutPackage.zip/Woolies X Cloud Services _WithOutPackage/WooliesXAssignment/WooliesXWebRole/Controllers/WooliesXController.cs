﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WooliesXBusiness;
using WooliesXBusiness.Interface;
using WooliesXBusiness.Model;

namespace WooliesXAPI.Controllers
{
    public class WooliesXController : ApiController
    {

        IUser user;
        IUser User
        {
            get
            {
                if (user == null)
                    user = ResolveDependency.GetInstanceGeneral<IUser>();

                return user;
            }
        }



        IProduct product;
        IProduct Product
        {
            get
            {
                if (product == null)
                    product = ResolveDependency.GetInstanceGeneral<IProduct>();

                return product;
            }
        }



        ITrolley trolley;
        ITrolley Trolley
        {
            get
            {
                if (trolley == null)
                    trolley = ResolveDependency.GetInstanceGeneral<ITrolley>();

                return trolley;
            }
        }

        [Route("api/WooliesX/user")]
        [HttpGet]
        public IHttpActionResult GetUser()
        {
            try
            {
                UserModel userModel =  User.GetUser();
                return Ok(userModel);
            }
            catch
            {
                return InternalServerError();
            }
        }

        [Route("api/WooliesX/products/sort")]
        [HttpGet]
        public IHttpActionResult  GetSortedProductst(string sortOption="low")
        {
            try
            {
                IList<ProductModel> listProductModels =  Product.GetSortedProducts(sortOption);
                if (listProductModels != null)
                {
                    return Ok(listProductModels);
                }
                else
                {
                    return BadRequest();
                }
            }
            catch(Exception exp)
            {
                return InternalServerError();
            }
        }


        [Route("api/WooliesX/trolleyTotal")]
        [HttpPost]
        public IHttpActionResult CalculateTrolleyTotal([FromBody] TrolleyModel trolleyModel)
        {
            try
            {
                decimal sum =  Trolley.CalculateTrolleyTotal(trolleyModel);
                return Ok(sum);
            }
            catch
            {
                return InternalServerError();
            }
        }
    }
}
