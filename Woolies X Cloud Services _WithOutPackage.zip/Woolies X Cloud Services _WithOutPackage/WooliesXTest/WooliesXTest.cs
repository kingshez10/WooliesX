﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WooliesXBusiness;
using WooliesXBusiness.Interface;
using WooliesXBusiness.Model;

namespace WooliesXTest
{
    [TestClass]
    public class WooliesXTest
    {
        [TestMethod]
        public void GetUser_Test()
        {
            //Arrange
            IUser user = new User();
            UserModel expectedUserModel = new UserModel();
            expectedUserModel.name = "Tippu Afsar Sardar";
            expectedUserModel.token = "9443a55b-b6c7-45b3-a872-528d733c267c";
            //Act
            UserModel actualUserModel = user.GetUser();
            //Assert
            Assert.IsNotNull(actualUserModel);
            Assert.AreEqual(expectedUserModel.name,actualUserModel.name);
            Assert.AreEqual(expectedUserModel.token, actualUserModel.token);
        }



        [TestMethod]
        public void GetSortedProducts_Low_Test()
        {
            //Arrange
            ICustomer customer = new Customer();
            IProduct product = new Product(customer);
            string sortOption = "low";
            IList<ProductModel> expectedSortedProductList = new List<ProductModel> { new ProductModel() { name= "Test Product D",price=5,quantity=0 },
                new ProductModel() { name= "Test Product C",price= 10.99M,quantity=0 },
                new ProductModel() { name= "Test Product A",price= 99.99M,quantity=0 },
                new ProductModel() { name= "Test Product B",price= 101.99M,quantity=0 },
                new ProductModel() { name= "Test Product F",price= 999999999999,quantity=0 },

            };

            //Act
            IList<ProductModel> actualSortedProductList = product.GetSortedProducts(sortOption);

            //Assert
            Assert.IsNotNull(actualSortedProductList);           
            Assert.AreEqual(expectedSortedProductList[0].name, actualSortedProductList[0].name);
            Assert.AreEqual(expectedSortedProductList[0].price, actualSortedProductList[0].price);
            Assert.AreEqual(expectedSortedProductList[1].name, actualSortedProductList[1].name);
            Assert.AreEqual(expectedSortedProductList[1].price, actualSortedProductList[1].price);
            Assert.AreEqual(expectedSortedProductList[2].name, actualSortedProductList[2].name);
            Assert.AreEqual(expectedSortedProductList[2].price, actualSortedProductList[2].price);
            Assert.AreEqual(expectedSortedProductList[3].name, actualSortedProductList[3].name);
            Assert.AreEqual(expectedSortedProductList[3].price, actualSortedProductList[3].price);
            Assert.AreEqual(expectedSortedProductList[4].name, actualSortedProductList[4].name);
            Assert.AreEqual(expectedSortedProductList[4].price, actualSortedProductList[4].price);
        }



        [TestMethod]
        public void GetSortedProducts_High_Test()
        {
            //Arrange
            ICustomer customer = new Customer();
            IProduct product = new Product(customer);
            string sortOption = "high";
            IList<ProductModel> expectedSortedProductList = new List<ProductModel> { 
                                                
                new ProductModel() { name= "Test Product F",price= 999999999999,quantity=0 },
                new ProductModel() { name= "Test Product B",price= 101.99M,quantity=0 },
                new ProductModel() { name= "Test Product A",price= 99.99M,quantity=0 },
                new ProductModel() { name= "Test Product C",price= 10.99M,quantity=0 },
                new ProductModel() { name= "Test Product D",price=5,quantity=0 }

            };

            //Act
            IList<ProductModel> actualSortedProductList = product.GetSortedProducts(sortOption);

            //Assert
            Assert.IsNotNull(actualSortedProductList);
            Assert.AreEqual(expectedSortedProductList[0].name, actualSortedProductList[0].name);
            Assert.AreEqual(expectedSortedProductList[0].price, actualSortedProductList[0].price);
            Assert.AreEqual(expectedSortedProductList[1].name, actualSortedProductList[1].name);
            Assert.AreEqual(expectedSortedProductList[1].price, actualSortedProductList[1].price);
            Assert.AreEqual(expectedSortedProductList[2].name, actualSortedProductList[2].name);
            Assert.AreEqual(expectedSortedProductList[2].price, actualSortedProductList[2].price);
            Assert.AreEqual(expectedSortedProductList[3].name, actualSortedProductList[3].name);
            Assert.AreEqual(expectedSortedProductList[3].price, actualSortedProductList[3].price);
            Assert.AreEqual(expectedSortedProductList[4].name, actualSortedProductList[4].name);
            Assert.AreEqual(expectedSortedProductList[4].price, actualSortedProductList[4].price);
        }



        [TestMethod]
        public void GetSortedProducts_Asscending_Test()
        {
            //Arrange
            ICustomer customer = new Customer();
            IProduct product = new Product(customer);
            string sortOption = "ascending";
            IList<ProductModel> expectedSortedProductList = new List<ProductModel> {                               
                new ProductModel() { name= "Test Product A",price= 99.99M,quantity=0 },
                new ProductModel() { name= "Test Product B",price= 101.99M,quantity=0 },
                new ProductModel() { name= "Test Product C",price= 10.99M,quantity=0 },
                new ProductModel() { name= "Test Product D",price=5,quantity=0 },
                new ProductModel() { name= "Test Product F",price= 999999999999,quantity=0 }
            };

            //Act
            IList<ProductModel> actualSortedProductList = product.GetSortedProducts(sortOption);

            //Assert
            Assert.IsNotNull(actualSortedProductList);
            Assert.AreEqual(expectedSortedProductList[0].name, actualSortedProductList[0].name);
            Assert.AreEqual(expectedSortedProductList[0].price, actualSortedProductList[0].price);
            Assert.AreEqual(expectedSortedProductList[1].name, actualSortedProductList[1].name);
            Assert.AreEqual(expectedSortedProductList[1].price, actualSortedProductList[1].price);
            Assert.AreEqual(expectedSortedProductList[2].name, actualSortedProductList[2].name);
            Assert.AreEqual(expectedSortedProductList[2].price, actualSortedProductList[2].price);
            Assert.AreEqual(expectedSortedProductList[3].name, actualSortedProductList[3].name);
            Assert.AreEqual(expectedSortedProductList[3].price, actualSortedProductList[3].price);
            Assert.AreEqual(expectedSortedProductList[4].name, actualSortedProductList[4].name);
            Assert.AreEqual(expectedSortedProductList[4].price, actualSortedProductList[4].price);
        }



        [TestMethod]
        public void GetSortedProducts_Descending_Test()
        {
            //Arrange
            ICustomer customer = new Customer();
            IProduct product = new Product(customer);
            string sortOption = "descending";
            IList<ProductModel> expectedSortedProductList = new List<ProductModel> {
                                                               
                new ProductModel() { name= "Test Product F",price= 999999999999,quantity=0 },
                new ProductModel() { name= "Test Product D",price=5,quantity=0 },
                new ProductModel() { name= "Test Product C",price= 10.99M,quantity=0 },
                new ProductModel() { name= "Test Product B",price= 101.99M,quantity=0 },
                new ProductModel() { name= "Test Product A",price= 99.99M,quantity=0 }
            };

            //Act
            IList<ProductModel> actualSortedProductList = product.GetSortedProducts(sortOption);

            //Assert
            Assert.IsNotNull(actualSortedProductList);
            Assert.AreEqual(expectedSortedProductList[0].name, actualSortedProductList[0].name);
            Assert.AreEqual(expectedSortedProductList[0].price, actualSortedProductList[0].price);
            Assert.AreEqual(expectedSortedProductList[1].name, actualSortedProductList[1].name);
            Assert.AreEqual(expectedSortedProductList[1].price, actualSortedProductList[1].price);
            Assert.AreEqual(expectedSortedProductList[2].name, actualSortedProductList[2].name);
            Assert.AreEqual(expectedSortedProductList[2].price, actualSortedProductList[2].price);
            Assert.AreEqual(expectedSortedProductList[3].name, actualSortedProductList[3].name);
            Assert.AreEqual(expectedSortedProductList[3].price, actualSortedProductList[3].price);
            Assert.AreEqual(expectedSortedProductList[4].name, actualSortedProductList[4].name);
            Assert.AreEqual(expectedSortedProductList[4].price, actualSortedProductList[4].price);
        }



        [TestMethod]
        public void GetSortedProducts_Recommended_Test()
        {
            //Arrange
            ICustomer customer = new Customer();
            IProduct product = new Product(customer);
            string sortOption = "recommended";
            IList<ProductModel> expectedSortedProductList = new List<ProductModel> {                                               
                new ProductModel() { name= "Test Product A",price= 99.99M,quantity=0 },
                new ProductModel() { name= "Test Product B",price= 101.99M,quantity=0 },
                new ProductModel() { name= "Test Product F",price= 999999999999,quantity=0 },
                new ProductModel() { name= "Test Product C",price= 10.99M,quantity=0 },
                new ProductModel() { name= "Test Product D",price=5,quantity=0 },
            };

            //Act
            IList<ProductModel> actualSortedProductList = product.GetSortedProducts(sortOption);

            //Assert
            Assert.IsNotNull(actualSortedProductList);
            Assert.AreEqual(expectedSortedProductList[0].name, actualSortedProductList[0].name);
            Assert.AreEqual(expectedSortedProductList[0].price, actualSortedProductList[0].price);
            Assert.AreEqual(expectedSortedProductList[1].name, actualSortedProductList[1].name);
            Assert.AreEqual(expectedSortedProductList[1].price, actualSortedProductList[1].price);
            Assert.AreEqual(expectedSortedProductList[2].name, actualSortedProductList[2].name);
            Assert.AreEqual(expectedSortedProductList[2].price, actualSortedProductList[2].price);
            Assert.AreEqual(expectedSortedProductList[3].name, actualSortedProductList[3].name);
            Assert.AreEqual(expectedSortedProductList[3].price, actualSortedProductList[3].price);
            Assert.AreEqual(expectedSortedProductList[4].name, actualSortedProductList[4].name);
            Assert.AreEqual(expectedSortedProductList[4].price, actualSortedProductList[4].price);
        }



        [TestMethod]
        public void GetSortedProducts_Invalid_Test()
        {
            //Arrange
            ICustomer customer = new Customer();
            IProduct product = new Product(customer);
            string sortOption = "test";
            IList<ProductModel> expectedSortedProductList = null;

            //Act
            IList<ProductModel> actualSortedProductList = product.GetSortedProducts(sortOption);

            //Assert
            Assert.IsNull(actualSortedProductList);
            Assert.AreEqual(expectedSortedProductList, actualSortedProductList);            
        }
    }
}
