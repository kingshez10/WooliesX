﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using WooliesXBusiness.Interface;
using WooliesXBusiness.Model;
using WooliesXBusiness.Utilities;

namespace WooliesXBusiness
{
    public class Product : IProduct
    {

        ICustomer customer;
        ICustomer Customer
        {
            get
            {
                if (customer == null)
                    customer = ResolveDependency.GetInstanceGeneral<ICustomer>();

                return customer;
            }
        }

        public Product()
        {
            
        }
        public Product(ICustomer _customer)
        {
            customer = _customer;
        }

        public IList<ProductModel> GetSortedProducts(string sortOption)
        {
            IList<ProductModel> listProductModel = null;
            if (sortOption.ToLower() == Constants.Recommended)
            {
                IList<CustomerOrderModel> listCustomerOrderModel = Customer.GetCustomerOrders();
                listProductModel = GetProductSortbyPopularity(listCustomerOrderModel);
            }
            else if(sortOption.ToLower() == Constants.Low || sortOption.ToLower() == Constants.High || sortOption.ToLower() == Constants.Ascending || sortOption.ToLower() == Constants.Descending)
            {
                listProductModel = GetProductsFromResource();

                switch (sortOption.ToLower())
                {
                    case Constants.Low:
                        listProductModel = listProductModel.OrderBy(X => X.price).ToList();
                        break;
                    case Constants.High:
                        listProductModel = listProductModel.OrderByDescending(X => X.price).ToList();
                        break;
                    case Constants.Ascending:
                        listProductModel = listProductModel.OrderBy(X => X.name).ToList();
                        break;
                    case Constants.Descending:
                        listProductModel = listProductModel.OrderByDescending(X => X.name).ToList();
                        break;
                }
            }
            return listProductModel;
        }

        private IList<ProductModel> GetProductsFromResource()
        {
            HttpResponseMessage response = ClientHTTPRequest.SendHttpRequest(ConfigurationManager.AppSettings["BaseURL"].ToString(), "api/resource/products?token="+ ConfigurationManager.AppSettings["Token"].ToString());
            if (response != null && response.IsSuccessStatusCode)
            {
                IList<ProductModel> listProductModel = JsonConvert.DeserializeObject<IList<ProductModel>>(response.Content.ReadAsStringAsync().Result);
                return listProductModel;
            }

            return null;
        }

        private IList<ProductModel> GetProductSortbyPopularity(IList<CustomerOrderModel> listCustomerOrder)
        {
            //Getting all products
            IList<ProductModel> listProductModels = GetProductsFromResource();
            //Getting Products in Customer Order 
            IList<ProductModel> listCusomterOrderProductModels = listCustomerOrder.SelectMany(X=>X.products).ToList();
            //Getting Popular product list
            IList<ProductPopularityModel> listProductPopularityModel = new List<ProductPopularityModel>();
            foreach (ProductModel product in listProductModels)
            {
                ProductPopularityModel productPopularityModel = new ProductPopularityModel();
                productPopularityModel.product = product;
                productPopularityModel.productcount = listCusomterOrderProductModels.Where(X => X.name == product.name).Count();
                listProductPopularityModel.Add(productPopularityModel);
            }

            //Sorting on the basis of product popularity
            listProductPopularityModel = listProductPopularityModel.OrderByDescending(X => X.productcount).ToList();
            return listProductPopularityModel.Select(X => X.product).ToList();
        }
    }
}
