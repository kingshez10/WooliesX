﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WooliesXBusiness.Model
{
    public class TrolleyModel
    {
       public IList<ProductModel>  products { get; set; }
       public IList<SpecialModel> specials { get; set; }
       public IList<QuantatyModel> quantities  { get; set; }
    }
}
