﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WooliesXBusiness.Model
{
    public class ProductPopularityModel
    {
        public int productcount { get; set; }

        public ProductModel product { get; set; }
    }
}
