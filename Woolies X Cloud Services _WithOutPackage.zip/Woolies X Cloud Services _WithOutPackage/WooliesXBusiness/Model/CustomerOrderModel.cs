﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WooliesXBusiness.Model
{
    public class CustomerOrderModel
    {
        public int customerId { get; set; }
        public IList<ProductModel> products { get; set; }

    }
}
