﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using WooliesXBusiness.Interface;
using WooliesXBusiness.Model;
using WooliesXBusiness.Utilities;

namespace WooliesXBusiness
{
    public class Trolley : ITrolley
    {
        public decimal CalculateTrolleyTotal(TrolleyModel trolleyModel)
        {
            return CalculateTotalFromResource(trolleyModel);
        }

        private decimal CalculateTotalFromResource(TrolleyModel trolleyModel)
        {
            decimal total = 0;
            string jsonData = JsonConvert.SerializeObject(trolleyModel);
            HttpResponseMessage response = ClientHTTPRequest.SendHttpPostRequest(ConfigurationManager.AppSettings["BaseURL"].ToString(), "api/resource/trolleyCalculator?token="+ ConfigurationManager.AppSettings["Token"].ToString(), jsonData);
            if (response != null && response.IsSuccessStatusCode)
            {
                total = JsonConvert.DeserializeObject<decimal>(response.Content.ReadAsStringAsync().Result);
            }

            return total;
        }
    }
}
