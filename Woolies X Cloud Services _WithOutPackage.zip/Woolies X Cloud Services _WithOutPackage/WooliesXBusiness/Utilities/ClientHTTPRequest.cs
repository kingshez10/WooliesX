﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace WooliesXBusiness.Utilities
{
    public static class ClientHTTPRequest
    {
        public static HttpResponseMessage SendHttpRequest(string baseURL, string apiURL)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseURL);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //GET Method  
                HttpResponseMessage response = client.GetAsync(apiURL).Result;
                return response;
            }
        }



        public static HttpResponseMessage SendHttpPostRequest(string baseURL, string apiURL, string data)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseURL);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, apiURL);
                //CONTENT-TYPE header
                request.Content = new StringContent(data,Encoding.UTF8,"application/json");
                //Post Method
                HttpResponseMessage response = client.SendAsync(request).Result;
                
                //HttpResponseMessage response = client.PostAsync(apiURL, new StringContent(data),).Result;
               
                return response;
            }
        }
    }
}
