﻿using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace WooliesXBusiness
{
    public static class ResolveDependency
    {
        #region Data Members
        private static IUnityContainer myContainer = null;
        private const string containerName = "WooliesXTestContainer";
        public static IUnityContainer ApplicationContainer
        {
            get
            {
                if ((HttpContext.Current == null) || (HttpContext.Current.Application[containerName] == null))
                    return null;
                else
                    return HttpContext.Current.Application[containerName] as IUnityContainer;
            }
            set
            {
                if (HttpContext.Current != null)
                {
                    HttpContext.Current.Application[containerName] = value;
                }
            }
        }
        #endregion

        #region Public Method
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public static T GetInstanceGeneral<T>() where T : class
        {
            return GetInstance<T>();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public static T GetInstanceNonWebGeneral<T>() where T : class
        {
            return GetInstanceNonWeb<T>();
        }

        /// <summary>
        /// This function is used to load container
        /// </summary>
        /// <returns>bool</returns>
        public static bool LoadContainer()
        {
            bool success = false;
            // create and populate a new Unity container from configuration
            UnityContainer myContainer = new UnityContainer();
            UnityConfigurationSection section = System.Configuration.ConfigurationManager.GetSection("unity") as UnityConfigurationSection;
            section.Configure(myContainer, containerName);
            ApplicationContainer = myContainer;
            if (myContainer != null)
            {
                success = true;
            }
            return success;
        }

        /// <summary>
        /// This function is used to unload container
        /// </summary>
        public static void UnloadContainer()
        {
            UnityContainer myContainer = ApplicationContainer as UnityContainer;

            if (myContainer != null)
            {
                myContainer.Dispose();
            }

            ApplicationContainer = null;
        }


        /// <summary>
        /// This function is used to retrive container
        /// </summary>
        /// <returns>IUnity Container</returns>
        public static IUnityContainer RetrieveContainer()
        {
            // found an existing container, so cast it to the correct type
            myContainer = ApplicationContainer;
            return myContainer;
        }

        #endregion

        #region Web



        /// <summary>
        /// This function is used to create and get instance with the help of unity 
        /// </summary>
        /// <typeparam name="T">Templated type</typeparam>
        /// <param name="typeName">Type Name</param>
        /// <returns>Templated Type</returns>
        private static T GetInstance<T>(string typeName) where T : class
        {
            myContainer = ApplicationContainer;
            T filleObject = null;
            filleObject = myContainer.Resolve<T>(typeName);
            return filleObject;
        }

        /// <summary>
        ///  This function is used to create and get instance with the help of unity 
        /// </summary>
        /// <typeparam name="T">Templated Type</typeparam>
        /// <returns>Templated Type</returns>
        private static T GetInstance<T>() where T : class
        {
            myContainer = ApplicationContainer;
            T filleObject = null;
            filleObject = myContainer.Resolve<T>();
            return filleObject;
        }

        /// <summary>
        /// This function is used to create and get instance with the help of unity
        /// </summary>
        /// <typeparam name="T">Templated Type</typeparam>
        /// <param name="typeName">Type Name</param>
        /// <param name="parameterOverride">Parameter Override</param>
        /// <returns>Templated Type</returns>
        private static T GetInstance<T>(string typeName, ParameterOverride parameterOverride) where T : class
        {
            myContainer = ApplicationContainer;
            T filleObject = null;
            filleObject = myContainer.Resolve<T>(typeName, parameterOverride);
            return filleObject;
        }

        /// <summary>
        /// This function is used to create and get instance with the help of unity
        /// </summary>
        /// <typeparam name="T">Templated Type</typeparam>
        /// <param name="typeName">Type Name</param>
        /// <param name="parameterOverride">List of Parameter Override</param>
        /// <returns>Templated Type</returns>
        private static T GetInstance<T>(ParameterOverrides parameterOverride) where T : class
        {
            myContainer = ApplicationContainer;
            T filleObject = null;
            filleObject = myContainer.Resolve<T>(parameterOverride);
            return filleObject;
        }




        #region Non Web

        /// <summary>
        /// This function is used to get the instance in unit test only
        /// </summary>
        /// <typeparam name="T">Template Type</typeparam>
        /// <param name="typeName">Type Name</param>
        /// <returns>Template Type</returns>
        private static T GetInstanceNonWeb<T>(string typeName) where T : class
        {
            IUnityContainer myContainer = new UnityContainer();
            UnityConfigurationSection section = System.Configuration.ConfigurationManager.GetSection("unity") as UnityConfigurationSection;
            section.Configure(myContainer, containerName);

            T filleObject = null;
            filleObject = myContainer.Resolve<T>(typeName);
            return filleObject;
        }

        /// <summary>
        /// This function is used to get the instance in unit test only
        /// </summary>
        /// <typeparam name="T">Template Type</typeparam>        
        /// <returns>Template Type</returns>
        private static T GetInstanceNonWeb<T>() where T : class
        {
            IUnityContainer myContainer = new UnityContainer();
            UnityConfigurationSection section = System.Configuration.ConfigurationManager.GetSection("unity") as UnityConfigurationSection;
            section.Configure(myContainer, containerName);
            T filleObject = null;
            filleObject = myContainer.Resolve<T>();
            return filleObject;
        }

        /// <summary>
        /// This function is used to create and get instance with the help of unity, it will be used in unit test only
        /// </summary>
        /// <typeparam name="T">Templated Type</typeparam>
        /// <param name="typeName">Type Name</param>
        /// <param name="parameterOverride">Parameter Override</param>
        /// <returns>Templated Type</returns>
        private static T GetInstanceNonWeb<T>(string typeName, ParameterOverride parameterOverride) where T : class
        {
            IUnityContainer myContainer = new UnityContainer();
            UnityConfigurationSection section = System.Configuration.ConfigurationManager.GetSection("unity") as UnityConfigurationSection;
            section.Configure(myContainer, containerName);
            T filleObject = null;
            filleObject = myContainer.Resolve<T>(typeName, parameterOverride);
            return filleObject;
        }
        #endregion 

        #endregion
    }
}
