﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WooliesXBusiness.Utilities
{
    public static class Constants 
    {
        public const string Low = "low";
        public const string High = "high";
        public const string Ascending = "ascending";
        public const string Descending = "descending";
        public const string Recommended = "recommended";
    }
}
