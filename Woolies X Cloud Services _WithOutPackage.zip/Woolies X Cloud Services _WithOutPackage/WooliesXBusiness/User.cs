﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WooliesXBusiness.Interface;
using WooliesXBusiness.Model;

namespace WooliesXBusiness
{
    public class User : IUser
    {
        public UserModel GetUser()
        {
            UserModel userModel = new UserModel();
            userModel.name = "Tippu Afsar Sardar";
            userModel.token = ConfigurationManager.AppSettings["Token"].ToString();
            return userModel;          
        }
    }
}
