﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WooliesXBusiness.Model;

namespace WooliesXBusiness.Interface
{
    public interface ICustomer
    {
        IList<CustomerOrderModel> GetCustomerOrders();
    }
}
