﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using WooliesXBusiness.Interface;
using WooliesXBusiness.Model;
using WooliesXBusiness.Utilities;

namespace WooliesXBusiness
{
    public class Customer : ICustomer
    {
        public IList<CustomerOrderModel> GetCustomerOrders()
        {
            IList<CustomerOrderModel> listCustomerModel = GetCustomerOrdersFromResource();
            return listCustomerModel;
        }




        private IList<CustomerOrderModel> GetCustomerOrdersFromResource()
        {
            HttpResponseMessage response = ClientHTTPRequest.SendHttpRequest(ConfigurationManager.AppSettings["BaseURL"].ToString(), "api/resource/shopperHistory?token="+ ConfigurationManager.AppSettings["Token"].ToString());
            if (response != null && response.IsSuccessStatusCode)
            {
                IList<CustomerOrderModel> listCustomerModel = JsonConvert.DeserializeObject<IList<CustomerOrderModel>>(response.Content.ReadAsStringAsync().Result);
                return listCustomerModel;
            }

            return null;
        }
    }
}
